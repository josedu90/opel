var gulp = require('gulp');
var concat = require('gulp-concat');
var sass = require('gulp-sass');
var uglify = require('gulp-uglify');
var uglifycss = require('gulp-uglifycss');
var webserver = require('gulp-webserver');
var autoprefixer = require('gulp-autoprefixer');

paths = {
	'bower': './bower_components',
	'assets': './assets'
};

// Copy Font Icons
gulp.task('font_icon', function() {
    return gulp.src([
		paths.bower + '/font-awesome/fonts/*',
		paths.bower + '/bootstrap/fonts/*',
		paths.assets + '/renticon/fonts/*',
    ])
    .pipe(gulp.dest('./public/assets/fonts'));
});

// Copy, compile, minify all icons
gulp.task('icon_style', function(){
	return gulp.src([
		paths.bower + '/font-awesome/css/font-awesome.css',
		paths.assets + '/renticon/css/renticon.css',
	])
	.pipe(concat('icons.min.css'))
	.pipe(uglifycss())
	.pipe(autoprefixer())
	.pipe(gulp.dest('./public/assets/css'));
});

// Copy, compile, minify all styles
gulp.task('styles', function(){
	return gulp.src([
		paths.assets + '/styles/sass/style.scss'
	])
	.pipe(sass({outputStyle: 'expanded'}).on('error', sass.logError))
	.pipe(concat('style.css'))
	.pipe(autoprefixer())
	.pipe(gulp.dest('./public/assets/css'));
});

// Copy Revslider All assets
gulp.task('revulation_slider', function() {
	return gulp.src([
		paths.assets + '/revolution'
	])
	.pipe(gulp.dest('./public/assets'));
});

// Copy jQuery UI slider All assets
gulp.task('jquery_ui_slider', function() {
	return gulp.src([
		paths.bower + '/jquery-ui-slider/jquery-ui.min.css',
		paths.bower + '/jquery-ui-slider/jquery-ui.min.js'
	])
	.pipe(gulp.dest('./public/assets/jquery-ui'));
});

//Copy, compile, minify all plugin css
gulp.task('plugin_css', function() {
	return gulp.src([
		paths.bower + '/bootstrap/dist/css/bootstrap.css',
		paths.bower + '/magnific-popup/dist/magnific-popup.css',
		paths.bower + '/owl.carousel/dist/assets/owl.carousel.css',
		paths.assets + '/plugin/datetimepicker-master/jquery.datetimepicker.css',
	])
	.pipe(concat('plugins.min.css'))
	.pipe(uglifycss())
	.pipe(autoprefixer())
	.pipe(gulp.dest('./public/assets/css'));
});

// Copy, compile, minify all colors
gulp.task('styles_colors', function(){
	return gulp.src([
		paths.assets + '/styles/colors/color-schemer.scss'
	])
	.pipe(sass({outputStyle: 'expanded'}).on('error', sass.logError))
	.pipe(concat('color-schemer.css'))
	.pipe(autoprefixer())
	.pipe(gulp.dest('./public/assets/css'));
});

// Copy, compile, minify all plug ins scripts
gulp.task('plugin_scripts', function(){
	gulp.src([
		paths.bower + '/jquery/dist/jquery.js',
		paths.bower + '/jquery-migrate/jquery-migrate.js',
		paths.bower + '/bootstrap/dist/js/bootstrap.js',
		paths.bower + '/owl.carousel/dist/owl.carousel.js',
		paths.bower + '/jquery-slimscroll/jquery.slimscroll.js',
		paths.bower + '/magnific-popup/dist/jquery.magnific-popup.js',
		paths.assets + '/plugin/datetimepicker-master/build/jquery.datetimepicker.full.js',
		paths.bower + '/jquery-countTo/jquery.countTo.js',
		paths.assets + '/js/syoTimer.js',
	])
	.pipe(concat('plugins.min.js'))
	.pipe(uglify())
	.pipe(gulp.dest('./public/assets/js'));
});

// Copy, compile, minify custom scripts
gulp.task('custom_scripts', function(){
	gulp.src([
		paths.assets + '/js/carrent.js',
	])
	.pipe(concat('carrent.min.js'))
	.pipe(gulp.dest('./public/assets/js'));
});

// Watch task 
gulp.task('watch', function(){
	gulp.watch(paths.assets + '/styles/**/*.scss', ['styles','styles_colors']);
	gulp.watch(paths.assets + '/js/**/*.js', ['custom_scripts']);
});

// Webserver task
gulp.task('webserver', function() {
	gulp.src('public')
	.pipe(webserver({
		livereload: true,
		directoryListing: false,
		fallback: './public/index.html',
		open: true
	}));
});

// Defualt task
gulp.task('default', ['styles', 'watch', 'webserver']);

// Task for starting webserver 
gulp.task('start', ['watch', 'webserver']);